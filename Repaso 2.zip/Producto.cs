﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LabRepaso2_Parcial2_
{
    public class Producto
    {
        public string codigo { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public double precioCompra { get; set; }
        public double precioVenta { get; set; }

    }
}